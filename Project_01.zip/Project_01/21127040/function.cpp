#include"header.h"

// LPCWSTR stands for Long Pointer to Constant Wide STRing.It is a 32 - bit pointer to a constant string 
// of 16 - bit Unicode characters, which may be null - terminated.
// In simple words, it is the same as a string but with wide characters.

// convert std::string to LPCWSTR
LPCWSTR string_to_LPCWSTR(string str)
{
	LPCWSTR result;

	wstring temp = wstring(str.begin(), str.end());
	result = temp.c_str();

	return result;
}

// convert int to hex(string) 
string convert_Int_to_HexStr(int x)
{
    ostringstream ss;
    ss << hex << x;
    string result = ss.str();

    return result;
}

// Convert hex(string) to int
int convert_HexStr_to_Int(string h)     //VD: string h = "1b"; 
{
	unsigned int result = stoul(h, nullptr, 16);
	return result;
}
