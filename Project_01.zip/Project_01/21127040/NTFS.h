﻿#pragma once
#include<iostream>
#include<string> 
#include<Windows.h>
#include <stdio.h>
#include<iomanip> 
#include<sstream> 
#include"header.h" 

using namespace std; 


wstring Input_diskName(); 

// Đọc PBS (Partition Boot Sector )
void Read_PBS(LPCWSTR disk, wstring diskName, BYTE*& PBS);

// in bảng PBS (Partition Boot Sector ) 
void print_PBS(BYTE*& PBS);


// kiểm tra byte X có phải là string gồm 2 ký tự không và sửa lại 
string str_1byte(string str); 
// tìm index của offset trong PBS[]
int find_index(string offset); 

//     ___  Đọc các thông tin cơ bản trong NTFS Partition Boot Sector  ___
int get_BytePerSector(BYTE*& PBS);     // kích thước 1 sector 
int get_SectorPerCluster(BYTE*& PBS);  // số sector trong 1 cluster 
int get_SectorPerTrack(BYTE*& PBS);    // số sector trong 1 track 
int get_NumberOfHeads(BYTE*& PBS);     // số mặt đĩa (head/ side) 
int get_logicStartingSector(BYTE*& PBS);      //Sector bắt đầu của ổ đĩa logic 
int get_NumberOfLogicDiskSectors(BYTE*& PBS); // Số sector của ổ đĩa logic
int get_StartingSectorOfMTF(BYTE*& PBS);      // Cluster bắt đầu của MFT  
int get_StartingSectorOfMTF_2(BYTE*& PBS);    // Cluster bắt đầu của MFT dự phòng 
int get_sizeOfEachMTFEntry(BYTE*& PBS);       // Kích thước của một bản ghi trong MFT (MFT entry), đơn vị tính là byte
int get_NumberOfIndexBufferClusters(BYTE*& PBS);// Số cluster của Index Buffer 
//int get_SeriOfDisk(BYTE*& PBS);               // Số seri của ổ đĩa (volume serial number) 
// xuất các thông tin cơ bản của NTFS Partition Boot Sector
void Print_BPB_inf(BYTE*& PBS); 




