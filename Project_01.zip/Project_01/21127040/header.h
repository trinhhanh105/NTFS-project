#pragma once
#include<iostream>
#include<string>
#include<Windows.h> 
#include<sstream> 
using namespace std;

// convert std::string to LPCWSTR
LPCWSTR string_to_LPCWSTR(string str); 

// Convert hex(string) to int
int convert_HexStr_to_Int(string h); 

// convert int to hex(string)  
string convert_Int_to_HexStr(int x); 


// Ref: 
// https://www.youtube.com/watch?v=UOE80utbQz8&list=PLlN-0IxDjtvKSJzClHtFrEtmxE60XZdkS&index=3 
// https://www.geeksforgeeks.org/cpp-program-to-get-the-list-of-files-in-a-directory/ 
// https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilea 
// https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilea
// https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfilepointer
// https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-readfile 





