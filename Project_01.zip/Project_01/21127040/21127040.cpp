﻿#include<iostream>
#include"NTFS.h" 
#include<iomanip>
#include"header.h" 

using namespace std; 

int main() 
{
    wstring diskName = Input_diskName();  
    wcout << diskName; 
    diskName = L"\\\\.\\" + diskName + L":"; 
    LPCWSTR disk = diskName.c_str(); 

    BYTE* PBS = new BYTE[512];

    Read_PBS(disk, diskName, PBS); 

    print_PBS(PBS); 


    Print_BPB_inf(PBS);  


 

    delete[] PBS; 

    


    return 0;
}