﻿#include"NTFS.h" 
using namespace std; 


wstring Input_diskName()
{
	wstring diskName;
	cout << "Nhap ten o dia: ";
	wcin >> diskName;
	return diskName;
}


// Đọc PBS (Partition Boot Sector ) 
void Read_PBS(LPCWSTR disk, wstring diskName, BYTE*& PBS)
{
    HANDLE hfile;
    hfile = CreateFile(disk,    
        GENERIC_READ,           
        FILE_SHARE_READ,         
        NULL,                   
        OPEN_EXISTING,          
        0,                      
        NULL);                  

    if (hfile == INVALID_HANDLE_VALUE)
    {
        cout << "\nunable to open file: ";
        wcout << diskName;
        return;
    }
    else
    {
        bool check = ReadFile(hfile, PBS, 512, NULL, NULL);
        if (check == false)
        {
            cout << "\nFailed to read file: " << GetLastError() << endl; 
        }
    }
}
// in bảng PBS (Partition Boot Sector )  
void print_PBS(BYTE*& PBS)
{
    cout << endl << endl;
    cout << "Partition Boot Sector: ";
    cout << endl << endl;

    for (int i = 0; i < 16; i++)
    {
        if (i == 0)
        {
            cout << setw(15) << hex << i;
        }
        else
        {
            cout << setw(4) << hex << i;
            if (i == 7)
                cout << "  ";
        }       
    }


    int count = 0;
    int idx = 0;

    while (count < 512 / 16)
    {
        cout << endl;
        cout << setfill('0') << setw(7) << hex << count;
        cout << setfill(' ') << "0     "; 

        for (int i = 0; i < 16; i++)
        {         
            cout << setfill('0') << setw(2) << hex << (int)PBS[idx];
            cout << setfill(' ') << "  ";

            if (i == 7)
                cout << "  ";
            idx++;

        }

        count++;
    }
    cout << dec; // trả về hệ dec 
}


// kiểm tra byte X có phải là string gồm 2 ký tự không: 
// nếu str.length() == 2  -> ko thay đổi
// nếu str.length() == 1  -> chuyển X thành dạng "0X" 
string str_1byte(string str)
{
    if (str.length() == 1)
    {
        str = "0" + str;
    }
    return str;
}
// tìm index của offset trong PBS[]
int find_index(string offset)
{
    string s1 = offset.substr(0, 1);
    string s2 = offset.substr(1);
    int i = convert_HexStr_to_Int(s1);
    int j = convert_HexStr_to_Int(s2);
    return i * 16 + j;
}

//     ___  Đọc các thông tin cơ bản trong NTFS Partition Boot Sector  ___

// kích thước 1 sector 
int get_BytePerSector(BYTE*& PBS)
{
    string offset = "0b"; // địa chỉ (offset) 
    int size = 2;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset); 

    for (int i = idx; i <= idx + size - 1; i++) 
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        //string temp = to_string((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }
    
    result = convert_HexStr_to_Int(result_hex); 
    return result; 
}
// số sector trong 1 cluster 
int get_SectorPerCluster(BYTE*& PBS) 
{
    string offset = "0d"; // địa chỉ (offset) 
    int size = 1;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    //int idx = convert_HexStr_to_Int(offset);
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// số sector trong 1 track 
int get_SectorPerTrack(BYTE*& PBS)
{
    string offset = "18"; // địa chỉ (offset) 
    int size = 2;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// số mặt đĩa (head/ side) 
int get_NumberOfHeads(BYTE*& PBS)
{
    string offset = "1a"; // địa chỉ (offset) 
    int size = 2;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
//Sector bắt đầu của ổ đĩa logic 
int get_logicStartingSector(BYTE*& PBS)
{
    string offset = "1c"; // địa chỉ (offset) 
    int size = 4;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// Số sector của ổ đĩa logic
int get_NumberOfLogicDiskSectors(BYTE*& PBS)
{
    string offset = "28"; // địa chỉ (offset) 
    int size = 8;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// Cluster bắt đầu của MFT   
int get_StartingSectorOfMTF(BYTE*& PBS)
{
    string offset = "30"; // địa chỉ (offset) 
    int size = 8;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// Cluster bắt đầu của MFT dự phòng 
int get_StartingSectorOfMTF_2(BYTE*& PBS)
{
    string offset = "38"; // địa chỉ (offset) 
    int size = 8;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// Kích thước của một bản ghi trong MFT (MFT entry), đơn vị tính là byte
int get_sizeOfEachMTFEntry(BYTE*& PBS)
{
    string offset = "40"; // địa chỉ (offset) 
    int size = 1;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// Số cluster của Index Buffer 
int get_NumberOfIndexBufferClusters(BYTE*& PBS)
{
    string offset = "44"; // địa chỉ (offset) 
    int size = 1;         // kích thước (byte)

    int result = 0;
    string result_hex = "";
    int idx = find_index(offset);

    for (int i = idx; i <= idx + size - 1; i++)
    {
        string temp = convert_Int_to_HexStr((int)PBS[i]);
        temp = str_1byte(temp);

        result_hex = temp + result_hex;
    }

    result = convert_HexStr_to_Int(result_hex);
    return result;
}
// Số seri của ổ đĩa (volume serial number) 
//int get_SeriOfDisk(BYTE*& PBS)
//{
//    string offset = "48"; // địa chỉ (offset) 
//    int size = 8;         // kích thước (byte)
//
//    int result = 0;
//    string result_hex = "";
//    int idx = find_index(offset);
//
//    for (int i = idx; i <= idx + size - 1; i++)
//    {
//        string temp = convert_Int_to_HexStr((int)PBS[i]);
//        temp = str_1byte(temp);
//
//        result_hex = temp + result_hex;
//    }
//
//    result = convert_HexStr_to_Int(result_hex);
//    return result;
//}

// xuất các thông tin cơ bản của NTFS Partition Boot Sector
void Print_BPB_inf(BYTE*& PBS)
{
    cout << endl; 
    cout << "Thong tin co ban cua NTFS Partition Boot Sector: " << endl;
    cout << " Kich thuoc 1 sector: " << get_BytePerSector(PBS) << " byte(s)" << endl;
    cout << " So sector trong 1 cluster: " << get_SectorPerCluster(PBS) << endl;
    cout << " So sector trong 1 track: " << get_SectorPerTrack(PBS) << endl;
    cout << " So mat dia (head/side): " << get_NumberOfHeads(PBS) << endl;
    cout << " Sector bat dau cua o dia logic: " << get_logicStartingSector(PBS) << endl;
    cout << " so Sector cua o dia logic: " << get_NumberOfLogicDiskSectors(PBS) << endl;
    cout << " Cluster bat dau cua MFT: " << get_StartingSectorOfMTF(PBS) << endl;
    cout << " Cluster bat dau cua MFT du phong: " << get_StartingSectorOfMTF_2(PBS) << endl;
    cout << " kich thuoc 1 ban ghi trong MFT (MFT entry): " << get_sizeOfEachMTFEntry(PBS) << " byte(s)" << endl;
    cout << " so Cluster cua Index Buffer: " << get_NumberOfIndexBufferClusters(PBS) << endl;
    //cout << "volume serial number: " << get_SeriOfDisk(PBS) << endl;

    cout << endl;
}
